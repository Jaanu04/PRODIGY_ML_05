# PRODIGY_ML_05

TASK 05: Develop a model that can accurately recognize food items from images and estimate their calorie content, enabling users to track their dietary intake and make informed food choices.

DATASET: https://www.kaggle.com/dansbecker/food-101

(Due to lack of knowledge, the code is not up to the mark, visit again in 7-10 days to get the improvised code)
